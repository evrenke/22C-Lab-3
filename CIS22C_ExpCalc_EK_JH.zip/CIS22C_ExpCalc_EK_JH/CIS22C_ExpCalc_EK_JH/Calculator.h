#pragma once
#include <string>
#include <iostream>
#include "Stack.h"
#include "Queue.h"

class Calculator
{
private:
	Stack<std::string> operators;
	Stack<int> operands;
public:
	~Calculator()
	{
		operators.~Stack();
		operands.~Stack();
	}
	void addOperand(int operand);
	void addOperator(std::string operatorInt);
	std::string formatInput(std::string input);

	std::string postfixTransformation(std::string s);
	int postfixCalculation(std::string s);

	std::string prefixTransformation(std::string s);
	void prefixCalculation(std::string s);
	void outputPrefixOperation(std::string output, int result);
};