#include "Calculator.h"

void Calculator::addOperand(int operand)
{
	operands.push(operand);
}

void Calculator::addOperator(std::string operatorStr)
{
	operators.push(operatorStr);
}

std::string Calculator::formatInput(std::string input)
{
	//change any user input into a single spaced format for other functions

	int length = input.length();//32
	int lastIndexOfElement = 1;
	if (length != 0 && input.at(0) == ' ')
	{
		input = input.substr(input.find_first_not_of(' '), length);
	}
	if (length != 0)
	{
		switch (input.at(0))// the first element might be a number
		{
		case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9': //scanning for more numerals
			while (lastIndexOfElement < length && (input.at(lastIndexOfElement) != '+' && input.at(lastIndexOfElement) != '-' && input.at(lastIndexOfElement) != '*'
				&& input.at(lastIndexOfElement) != '/' && input.at(lastIndexOfElement) != '%' && input.at(lastIndexOfElement) != '('
				&& input.at(lastIndexOfElement) != ')' && input.at(lastIndexOfElement) != ' ') )
			{
				lastIndexOfElement++;
			}
		break;
		case '+':case '-':case '*':case '/':case '%':case '(':case ')':case ' ':
		break;
		default:
			throw "That is not a math expression";
		}
		if (lastIndexOfElement < length)
		{
			input = input.substr(0, lastIndexOfElement) + " " + formatInput(input.substr(lastIndexOfElement, length));
		}
	}
	return input;
}

std::string Calculator::postfixTransformation(std::string input)
{
	std::string transformed = "";
	int priority = 0;
	// input is "575 * ( 7 - 5 / 2 + 1 % 8 - ( 3 * 3 % 6 + 4 / 2 ) / ( 1 + 1 * 2 ) ) "
	// transformed becomes "575 7 5 2 / - 1 8 % + 3 3 * 6 % 4 2 / + 1 1 2 * + / - *

	while (input.length() > 1)
	{
		std::string removed = input.substr(0, input.find_first_of(' '));
		input = input.substr(input.find_first_of(' ') + 1, input.length());
		
		bool isFirstNumber = true;

		if (removed.at(0) == '-' || removed.at(0) == '+')
		{
			
			while (!operators.isEmpty() && operators.peek() != "(")
			{
				
				transformed += operators.peek();
				operators.pop();
				transformed += " ";
			}
			operators.push(removed);
		}
		else if(removed.at(0) == '*'
			|| removed.at(0) == '/' || removed.at(0) == '%')
		{
			while (!operators.isEmpty() && (operators.peek() != "(" 
				&& operators.peek() != "-" && operators.peek() != "+") )
			{
				transformed += operators.peek();
				operators.pop();
				transformed += " ";
			}
			operators.push(removed);
		}
		else if (removed.at(0) == '(')
		{
			operators.push(removed);
		}
		else if (removed.at(0) == ')')
		{
			while (!operators.isEmpty() && (operators.peek() != "("))
			{
				transformed += operators.peek();
				transformed += " ";
				operators.pop();
			}
			operators.pop();// pops a '('
		}
		
		else //its a number
		{
			transformed += removed;
			transformed += " ";
		}
	}
	while (!operators.isEmpty() && (operators.peek() != "("))
	{
		transformed += operators.peek();
		transformed += " ";
		operators.pop();
	}
	operators.pop();
	while (!operators.isEmpty())
	{
		transformed += operators.peek();
		transformed += " ";
		operators.pop();
	}
	return transformed;
}

int Calculator::postfixCalculation(std::string input)
{
	// input is  "575 7 5 2 / - 1 8 % + 3 3 * 6 % 4 2 / + 1 1 2 * + / - *
	// calculation result becomes 25
	int calculation = 0;
	int operandCount = 0;
	while (input.length() != 0)
	{
		std::string removed = input.substr(0, input.find_first_of(' '));
		input = input.substr(input.find_first_of(' ') + 1, input.length());
		if (removed.at(0) == '0' || removed.at(0) == '1' || removed.at(0) == '2' || removed.at(0) == '3'
			|| removed.at(0) == '4' || removed.at(0) == '5' || removed.at(0) == '6' || removed.at(0) == '7'
			|| removed.at(0) == '8' || removed.at(0) == '9')
		{
			operands.push(std::stoi(removed));
			operandCount++;
		}
		else if(operandCount >= 2)
		{
			int second = operands.peek();
			operands.pop();
			int first = operands.peek();
			operands.pop();
			operandCount -= 2;
			switch (removed.at(0))
			{
			case '+':
				calculation = first + second;
				std::cout << "The calculation: " << first << " + " << second << " = " << calculation << std::endl;
				break;
			case '-':
				calculation = first - second;
				std::cout << "The calculation: " << first << " - " << second << " = " << calculation << std::endl;
				break;
			case '*':
				calculation = first * second;
				std::cout << "The calculation: " << first << " * " << second << " = " << calculation << std::endl;
				break;
			case '/':
				calculation = first / second;
				std::cout << "The calculation: " << first << " / " << second << " = " << calculation << std::endl;
				break;
			case '%':
				calculation = first % second;
				std::cout << "The calculation: " << first << " % " << second << " = " << calculation << std::endl;
				break;
			}
			operands.push(calculation);
			operandCount++;
		}
	}
	
	return calculation;
}

std::string Calculator::prefixTransformation(std::string input)
{
	std::string transformed = "";
	int priority = 0;
	// input is "575 * ( 7 - 5 / 2 + 1 % 8 - ( 3 * 3 % 6 + 4 / 2 ) / ( 1 + 1 * 2 ) ) "
	// transformed becomes " * 5 - 7 + / 5 2 - % 1 8 / + % * 3 3 6 / 4 2 + 1 * 1 2 

	while (input.length() > 1)
	{
		std::string removed = input.substr(input.find_last_of(' ') + 1, input.length());
		input = input.substr(0, input.find_last_of(' '));

		bool isFirstNumber = true;

		if (removed.at(0) == '-' || removed.at(0) == '+')
		{

			while (!operands.isEmpty() && operators.peek() != "(")
			{
				transformed += removed;
				transformed += " ";
				transformed += operands.peek();
				operands.pop();
				transformed += operands.peek();
				operands.pop();
				
			}
			
		}
		else if (removed.at(0) == '*'
			|| removed.at(0) == '/' || removed.at(0) == '%')
		{
			while (!operands.isEmpty() && (operators.peek() != ")"
				&& operators.peek() != "-" && operators.peek() != "+"))
			{
				transformed += removed;
				transformed += " ";
				transformed += operands.peek();
				operands.pop();
				transformed += operands.peek();
				operands.pop();
			}
			
		}
		else if (removed.at(0) == '(')
		{
			while (!operators.isEmpty() && (operators.peek() != "("))
			{
				transformed += ")";
				transformed += " ";
				transformed += operands.peek();
				operands.pop();
				transformed += operands.peek();
				operands.pop();
			}
			operators.pop();// pops a ')'
			
		}
		else if (removed.at(0) == ')')
		{
			operators.push("(");
		}

		else //its a number
		{
			operands.push(std::stoi(removed));// transformed += removed;
			//transformed += " ";
		}
		std::cout << transformed << std::endl;
	}
	while (!operators.isEmpty() && (operators.peek() != "("))
	{
		transformed += operators.peek();
		transformed += " ";
		transformed += operands.peek();
		operands.pop();
		transformed += operands.peek();
		operands.pop();
		operators.pop();
	}
	while (!operands.isEmpty())
	{
		transformed += operands.peek();
		operands.pop();
		transformed += operands.peek();
		operands.pop();
	}
	return transformed;
}