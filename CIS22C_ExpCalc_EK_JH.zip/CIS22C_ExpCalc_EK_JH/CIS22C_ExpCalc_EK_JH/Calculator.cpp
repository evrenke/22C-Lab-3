#include "Calculator.h"

void Calculator::addOperand(int operand)
{
	operands.push(operand);
}

void Calculator::addOperator(std::string operatorStr)
{
	operators.push(operatorStr);
}

bool Calculator::expressionValidator(std::string input)
{
	//every mathematical expression needs to have 
	//numbers and operators
	//and it needs to start with a valid number or parantheses
	//every expression needs a number operator number "sandwich"
	//to be valid
	//parantheses need to have valid subexpressions
	//which are validated recurcively
	input = formatInput(input);
	std::cout << input << std::endl;
	bool isTryingANumber = true;// first element needs to be a number
	std::string firstElement = "";

	while (input.length() != 0)
	{
		firstElement = input.substr(0, input.find(' '));
		input = input.substr(input.find(' ') + 1, input.length());

		if ((input.at(0) < 49 || input.at(0) > 57) //not a number
			&& (input.at(0) < 40 || input.at(0) > 43) //not a paranthesis, multiplier, or plus
			&& (input.at(0) != 45) //not a minus sign
			&& (input.at(0) != 47)) // not a divisor
			return false;//this means that a non-mathematical expression character is being used
		if (input.at(0) == 40)// opening paranthesis
		{
			if (!expressionValidator(input.substr(1, input.find(')'))))
				return false;
		}
		else if (input.at(0) == 41)//closing paranthesis
		{
			return expressionValidator(input.substr(1, input.length()));
		}
		else if (isTryingANumber && (input.at(0) < 49 || input.at(0) > 57))//not a number when it should be
			return false;
		else if (!isTryingANumber && (input.at(0) >= 49 && input.at(0) <= 57))//is a number when it should not be
			return false;
		else isTryingANumber = !isTryingANumber;

	}


	return true;
}

std::string Calculator::formatInput(std::string input)
{
	//change any user input into a single spaced format for other functions
	while (input.find(' ') != -1)
	{
		input = input.substr(0, input.find(' ') ) + input.substr(input.find(' ') + 1, input.length());
	}

	int length = input.length();//32
	int lastIndexOfElement = 0;
	if (length != 0)
	{
		switch (input.at(lastIndexOfElement))// the first element might be a number
		{
		case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9': //scanning for more numerals
			while (lastIndexOfElement < length && (input.at(lastIndexOfElement) >= 49 && input.at(lastIndexOfElement) <= 57))
			{
				lastIndexOfElement++;
			}
		break;
		default://case '+':case '-':case '*':case '/':case '%':case '(':case ')':case ' ':
			lastIndexOfElement = 1;
		break;
		}
		if (lastIndexOfElement < length)
		{
			input = input.substr(0, lastIndexOfElement) + " " + formatInput(input.substr(lastIndexOfElement, length));
		}
	}
	return input;
}

std::string Calculator::postfixTransformation(std::string input)
{
	std::string transformed = "";
	// input is "5 * ( 7 - 5 / 2 + 1 % 8 - ( 3 * 3 % 6 + 4 / 2 ) / ( 1 + 1 * 2 ) ) "
	// transformed becomes "5 7 5 2 / - 1 8 % + 3 3 * 6 % 4 2 / + 1 1 2 * + / - *
	std::string removed = "";
	while (input.length() != 0)
	{
		if (input.find(' ') == -1)
		{
			removed = input;
			input = "";
		}
		else
		{
			/*
			removed = input.substr(input.find_last_of(' ') + 1, input.length());
			input = input.substr(0, input.find_last_of(' '));
			*/
			removed = input.substr(0, input.find(' '));
			input = input.substr(input.find(' ') + 1, input.length());
		}
		
		bool isFirstNumber = true;
		if (removed.at(0) == '-' || removed.at(0) == '+')
		{
			
			while (!operators.isEmpty() && operators.peek() != "(")
			{
				
				transformed += operators.peek();
				operators.pop();
				transformed += " ";
			}
			operators.push(removed);
		}
		else if( removed.at(0) == '/')
		{
			while (!operators.isEmpty() && (operators.peek() != "(" 
				&& operators.peek() != "-" && operators.peek() != "+") )
			{
				transformed += operators.peek();
				operators.pop();
				transformed += " ";
			}
			operators.push(removed);
		}
		else if (removed.at(0) == '%')
		{
			while (!operators.isEmpty() && (operators.peek() != "("
				&& operators.peek() != "-" && operators.peek() != "+")
				&& operators.peek() != "/")
			{
				transformed += operators.peek();
				operators.pop();
				transformed += " ";
			}
			operators.push(removed);
		}
		else if (removed.at(0) == '*')
		{
			while (!operators.isEmpty() && (operators.peek() != "("
				&& operators.peek() != "-" && operators.peek() != "+")
				&& operators.peek() != "%" && operators.peek() != "/")
			{
				transformed += operators.peek();
				operators.pop();
				transformed += " ";
			}
			operators.push(removed);
		}
		else if (removed.at(0) == '(')
		{
			operators.push(removed);
		}
		else if (removed.at(0) == ')')
		{
			while (!operators.isEmpty() && (operators.peek() != "("))
			{
				transformed += operators.peek();
				transformed += " ";
				operators.pop();
			}
			operators.pop();// pops a '('
		}
		else //its a number
		{
			transformed += removed;
			transformed += " ";
		}
	}
	while (!operators.isEmpty() && (operators.peek() != "("))
	{
		transformed += operators.peek();
		transformed += " ";
		operators.pop();
	}
	operators.pop();
	while (!operators.isEmpty())
	{
		transformed += operators.peek();
		transformed += " ";
		operators.pop();
	}
	transformed = transformed.substr(0, transformed.length() - 1);
	while (!operators.isEmpty())
	{
		operators.pop();
	}
	return transformed;
}

int Calculator::postfixCalculation(std::string input)
{
	// input is  "5 7 5 2 / - 1 8 % + 3 3 * 6 % 4 2 / + 1 1 2 * + / - *
	// calculation result becomes 25

	int calculation = 0;
	int operandCount = 0;
	std::string removed = "";
	while (input.length() != 0)
	{
		if (input.length() == 1)
		{
			removed = input;
			input = "";
		}
		else
		{
			removed = input.substr(0, input.find_first_of(' '));
			input = input.substr(input.find_first_of(' ') + 1, input.length());
		}
		if (removed.at(0) == '0' || removed.at(0) == '1' || removed.at(0) == '2' || removed.at(0) == '3'
			|| removed.at(0) == '4' || removed.at(0) == '5' || removed.at(0) == '6' || removed.at(0) == '7'
			|| removed.at(0) == '8' || removed.at(0) == '9')
		{
			operands.push(std::stoi(removed));
			operandCount++;
			
		}
		else if(operandCount >= 2)
		{
			int second = operands.peek();
			operands.pop();
			int first = operands.peek();
			operands.pop();
			operandCount -= 2;
			switch (removed.at(0))
			{
			case '+':
				calculation = first + second;
				std::cout << "The calculation: " << first << " + " << second << " = " << calculation << std::endl;
				break;
			case '-':
				calculation = first - second;
				std::cout << "The calculation: " << first << " - " << second << " = " << calculation << std::endl;
				break;
			case '*':
				calculation = first * second;
				std::cout << "The calculation: " << first << " * " << second << " = " << calculation << std::endl;
				break;
			case '/':
				calculation = first / second;
				std::cout << "The calculation: " << first << " / " << second << " = " << calculation << std::endl;
				break;
			case '%':
				calculation = first % second;
				std::cout << "The calculation: " << first << " % " << second << " = " << calculation << std::endl;
				break;
			}
			operands.push(calculation);
			operandCount++;
		}
	}
	operands.pop();
	while (!operands.isEmpty())
	{
		operands.pop();
	}
	return calculation;
}

std::string Calculator::prefixTransformation(std::string input)
{
	std::string transformed = "";
	std::string removed = "";
	while (input.length() > 0)
	{
		if (input.find(' ') == -1)
		{
			removed = input;
			input = "";
		}
		else
		{
			removed = input.substr(input.find_last_of(' ') + 1, input.length());
			input = input.substr(0, input.find_last_of(' '));
		}
		
			
		if (removed.at(0) == '(')
		{
			transformed += ")";
		}
		else if (removed.at(0) == ')')
		{
			transformed += "(";
		}
		else
		{
			transformed += removed;
		}
		transformed += " ";
	}
	//its formatted like postfix, but this leaves it backwards
	transformed = transformed.substr(0, transformed.length() - 1);
	std::cout << "W" << transformed << "w" << std::endl;
	transformed= postfixTransformation(transformed);
	std::cout << "W" << transformed << "w" << std::endl;
	
	std::string flipped = "";
	while (transformed.length() > 0)
	{
		if (transformed.find(' ') == - 1)
		{
			removed = transformed;
			transformed = "";
		}
		else
		{
			removed = transformed.substr(transformed.find_last_of(' ') + 1, transformed.length());
			transformed = transformed.substr(0, transformed.find_last_of(' '));
		}
		flipped += removed;
		flipped += " ";
	}
	flipped = flipped.substr(0, flipped.length() - 1);
	while (!operators.isEmpty())
	{
		operators.pop();
	}
	return flipped;
}

int Calculator::prefixCalculation(std::string input)
{
	// input is  " * 5 - 7 + / 5 2 - % 1 8 / + % * 3 3 6 / 4 2 + 1 * 1 2 
	// calculation result becomes 25
	std::cout << input << std::endl;

	int calculation = 0;
	bool hasOperator = false;
	int operandCount = 0;
	std::string removed = "";


	while (input.length() != 0)
	{
		if (input.find(' ') == -1)
		{
			removed = input;
			input = "";
		}
		else
		{
			removed = input.substr(input.find_last_of(' ') + 1, input.length());
			input = input.substr(0, input.find_last_of(' '));
		}
		if (removed.at(0) == '0' || removed.at(0) == '1' || removed.at(0) == '2' || removed.at(0) == '3'
			|| removed.at(0) == '4' || removed.at(0) == '5' || removed.at(0) == '6' || removed.at(0) == '7'
			|| removed.at(0) == '8' || removed.at(0) == '9')
		{
			operands.push(std::stoi(removed));
			operandCount++;
		}
		else if(!hasOperator)
		{
			operators.push(removed);
			hasOperator = true;
		}
		if (hasOperator && operandCount>= 2)
		{
			int first = operands.peek();
			operands.pop();
			int second = operands.peek();
			operands.pop();
			operandCount -= 2;
			switch (removed.at(0))
			{
			case '+':
				calculation = first + second;
				std::cout << "The calculation: " << first << " + " << second << " = " << calculation << std::endl;
				break;
			case '-':
				calculation = first - second;
				std::cout << "The calculation: " << first << " - " << second << " = " << calculation << std::endl;
				break;
			case '*':
				calculation = first * second;
				std::cout << "The calculation: " << first << " * " << second << " = " << calculation << std::endl;
				break;
			case '/':
				calculation = first / second;
				std::cout << "The calculation: " << first << " / " << second << " = " << calculation << std::endl;
				break;
			case '%':
				calculation = first % second;
				std::cout << "The calculation: " << first << " % " << second << " = " << calculation << std::endl;
				break;
			}
			operands.push(calculation);
			operandCount++;
			hasOperator = false;
		}
	}
	while (!operators.isEmpty())
	{
		operators.pop();
	}
	while (!operands.isEmpty())
	{
		operands.pop();
	}
	return calculation;
}