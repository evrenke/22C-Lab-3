#include "Calculator.h"
#include <iostream>
#include <string>

using namespace std;
int main()
{
	Calculator expCalc;

	/*
	string userInput = "";
	cout << " Welcome! This program will take a user input math expression" << endl;
	cout << "and calculate its value using postfix and prefix calculations" << endl;
	cout << "-------------------------------------------------------------" << endl;
	do
	{
		cout << "Enter the math expression or type nothing to end the program:"
		cin >> userInput;
	} while(userInput != "");
	*/

	string input = expCalc.formatInput("5*(7-5/2+1%8-(3*3%6+4/2)/(1+1*2))");
	
	cout << "Input formatted properly for transformation:" << endl;
	cout << input << endl << endl;

	string postfix = expCalc.postfixTransformation(input);
	cout << "Now the input has been formatted for postfix calculation: " << endl;
	cout << postfix << endl;

	int postfixResult = expCalc.postfixCalculation(postfix);
	cout << "The final result of the postfix calculation: " << postfixResult << endl;

	cout << "Now to test one for a prefix calculation ... FUCK YOU JAMES" << endl;
	cout << "Same input as before: " << endl;
	cout << input << endl << endl;

	string prefix = expCalc.prefixTransformation(input);

	system("pause");
	return 0;
}